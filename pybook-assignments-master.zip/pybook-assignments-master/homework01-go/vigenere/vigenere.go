package vigenere

func EncryptVigenere(plaintext string, keyword string) string {
	var ciphertext string

	// PUT YOUR CODE HERE

	return ciphertext
}

func DecryptVigenere(ciphertext string, keyword string) string {
	var plaintext string

	// PUT YOUR CODE HERE

	return plaintext
}
