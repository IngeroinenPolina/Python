package caesar

func EncryptCaesar(plaintext string, shift int) string {
	var ciphertext string

	// PUT YOUR CODE HERE

	return ciphertext
}

func DecryptCaesar(ciphertext string, shift int) string {
	var plaintext string

	// PUT YOUR CODE HERE

	return plaintext
}
