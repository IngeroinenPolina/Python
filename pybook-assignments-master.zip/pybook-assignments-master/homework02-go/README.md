Пример запуска тестов:

```
$ go test -v
=== RUN   TestGroup
--- PASS: TestGroup (0.00s)
=== RUN   TestGetCol
--- PASS: TestGetCol (0.00s)
=== RUN   TestGetRow
--- PASS: TestGetRow (0.00s)
=== RUN   TestGetBlock
--- PASS: TestGetBlock (0.00s)
=== RUN   TestFindEmptyPosition
--- PASS: TestFindEmptyPosition (0.00s)
=== RUN   TestFindPossibleValues
--- PASS: TestFindPossibleValues (0.00s)
=== RUN   TestSolve
--- PASS: TestSolve (0.00s)
=== RUN   TestCheckSolution
--- PASS: TestCheckSolution (0.00s)
=== RUN   TestGenerateSudoku
--- PASS: TestGenerateSudoku (0.00s)
PASS
ok  _/homework02-go  0.010s
```

