# https://hackernoon.com/4-ways-to-manage-the-configuration-in-python-4623049e841b

VK_CONFIG = {
    "domain": "https://api.vk.com/method",
    "access_token": "",
    "version": "5.126",
}
