# Шаблоны заданий для [практикума по Питону](https://github.com/Dementiy/Dementiy.github.io)

Шаблоны представлены на двух языках: Python и Go. Шаблоны для Go расположены в папках homework#-go.
