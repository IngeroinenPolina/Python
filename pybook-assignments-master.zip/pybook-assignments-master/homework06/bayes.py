class NaiveBayesClassifier:

    def __init__(self, alpha):
        pass

    def fit(self, X, y):
        """ Fit Naive Bayes classifier according to X, y. """
        pass

    def predict(self, X):
        """ Perform classification on an array of test vectors X. """
        pass

    def score(self, X_test, y_test):
        """ Returns the mean accuracy on the given test data and labels. """
        pass

